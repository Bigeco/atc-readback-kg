# ATC readback temporal KG (public release)

Run `katl_moss38`: KATL (Atlanta) LiveATC archives of 2024-08-26, 7,641 transmissions, 1,624 flights.

Transcripts and audio are **not included**: LiveATC.net terms allow personal, non-commercial use only and forbid
redistribution. Each transmission keeps the archive file name and the offsets (`offset_start`, `offset_end`, seconds),
so the source can be located in the same LiveATC archive (e.g. the Hugging Face dataset `nyuuzyou/liveatc`).

## Files
| file | content |
|---|---|
| `graph.json` | `{"nodes": [...], "edges": [...]}`; node = `{id, label, props}`, edge = `{id, type, src, dst, props}` |
| `neo4j/` | the same graph as CSV + `import.cypher` |
| `alerts.json` | rule alerts (M5) with evidence node ids |
| `summary.json` | node/edge counts, readback status, alert counts |

## Removed fields
- `Transmission.text` (transcript); `Transmission.file` reduced to the archive name
- `Instruction.qualifier`, `Instruction.target_text`, and `Instruction.value` unless it is a number or code
  (frequency, heading, altitude, squawk, runway); the same value is cut from POST_HANDOFF alert messages

## Node types
Transmission, Instruction (time-stamped events); Flight, CallsignMention (entities); Role, Airline, Airport,
Runway, Taxiway, Ramp, Facility (static KB). Edge types: SPOKEN_BY, CONTAINS, ADDRESSES, ALIAS, OPERATED_BY,
TARGET, VIA, PART_OF, NEXT, READBACK_OF (props `status` = MATCH / PARTIAL / MISMATCH).
Times are UTC epoch seconds: `valid_from`/`valid_to` on instructions, `ingested_at` on edges.
