// Requires APOC. Copy nodes.csv / relationships.csv into the Neo4j import directory.
LOAD CSV WITH HEADERS FROM 'file:///nodes.csv' AS row
CALL apoc.create.node([row.label], apoc.map.merge({id: row.id}, apoc.convert.fromJsonMap(row.props_json))) YIELD node
RETURN count(node);

CREATE INDEX node_id IF NOT EXISTS FOR (n:Transmission) ON (n.id);

LOAD CSV WITH HEADERS FROM 'file:///relationships.csv' AS row
MATCH (a {id: row.src}), (b {id: row.dst})
CALL apoc.create.relationship(a, row.type, apoc.convert.fromJsonMap(row.props_json), b) YIELD rel
RETURN count(rel);
